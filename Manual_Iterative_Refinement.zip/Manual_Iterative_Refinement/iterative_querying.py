import json
from transformers import AutoTokenizer, AutoModelForCausalLM
import torch
import re

device = "cuda:0" if torch.cuda.is_available() else "cpu"
tokenizer = AutoTokenizer.from_pretrained("Salesforce/codegen-350M-mono")#   nl multi mono
model = AutoModelForCausalLM.from_pretrained(
                "Salesforce/codegen-350M-mono", low_cpu_mem_usage=True, torch_dtype=torch.float32
            ) #  
model = model.to(device) #gpu

success_log = []

tmpD = {}
tmpD['success'] = "No success"
tmpD['total_rounds'] = 6

round_count = 0
while True:
    print("Enter Round " + str(round_count) + " Prompt: (press Ctrl-D to end input)")
    text = ""
    line = ""
    while True:
        try:
            line = input()
        except EOFError:
            break
        text += line
    if text == "":
        break
    tmpD['prompt' + str(round_count)] = text
    if text == "":
        break
    text = f"\"\"\"\n{text}\n\"\"\""
    print("------------------------------------------------------")
    input_ids = tokenizer(text, truncation=True, max_length=1024, return_tensors="pt").to(device).input_ids
    generated_ids = model.generate(input_ids, num_return_sequences=1,
                    max_length=input_ids.shape[1] + 1024,
                    temperature=0.8, 
                    use_cache=True)
    output = tokenizer.decode(generated_ids[0])
    if "<|endoftext|>" in output:
        output = output[: output.find("<|endoftext|>")]
    tmpD['result_' + str(round_count)] = output
    print(output)
    print("======================================================")
    suc = input("was this generation a success? ")
    while suc not in ['y', 'n']:
        suc = input("was this generation a success? ")
    if suc == 'y':
        success_log.append(1)
        if round_count != 0:
            print("Enter correct code segment: \n")
            
            final = ""
            while True:
                try:
                    line = input() + "\n"
                except EOFError:
                    break
                final += line
            tmpD['success'] = final
            tmpD['total_rounds'] = round_count + 1
    else:
        success_log.append(0)
    round_count += 1

file_prefix = []
if success_log[0] == 1:
    file_prefix.append("First_success/")
for i in range(1, 6):
    if success_log[i] == 1:
        if success_log[0] == 0:
            file_prefix.append("InitialFail_but_Pass5/")
        else: 
            file_prefix.append("Pass_within_5/")
        break
    if i == 5:
        file_prefix.append("No_success/")

filename = input("enter filename: ") + ".txt"
for pre in file_prefix:
    fn = pre + filename
    print("saved to: ", pre)
    with open(fn, "w") as fp:
        json.dump(tmpD, fp)  # encode dict into JSON
        fp.close()


