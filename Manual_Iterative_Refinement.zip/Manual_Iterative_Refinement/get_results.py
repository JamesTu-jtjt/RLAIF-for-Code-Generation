import sys
import argparse
import json

def get_result(filename, logs):
    with open(filename, "r") as fp:
        tmpD = json.load(fp)
        fp.close()
    if logs:
        for i in range(tmpD['total_rounds']):
            print("prompt", i, ": \n", tmpD['prompt' + str(i)])
            print("result", i, ": \n", tmpD['result_' + str(i)])
            print("=================================================================")
    else:
        print("Prompt: \n", tmpD['prompt0'])
    print("Final Result: \n", tmpD['success'])


def parse_args():
    parser = argparse.ArgumentParser(
        description="Run a trained model to generate Python code for the MBPP benchmark."
    )
    parser.add_argument(
        "--filename"
    )
    parser.add_argument(
        "--logs", default=False
    )
    args = parser.parse_args()
    return args


def main(args):
    get_result(args.filename, args.logs)



if __name__ == "__main__":
    main(parse_args())