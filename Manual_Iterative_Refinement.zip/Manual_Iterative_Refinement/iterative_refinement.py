import json
from transformers import AutoTokenizer, AutoModelForCausalLM
import torch
import re

device = "cuda:0" if torch.cuda.is_available() else "cpu"
tokenizer = AutoTokenizer.from_pretrained("Salesforce/codegen-350M-mono")#   nl multi mono
model = AutoModelForCausalLM.from_pretrained(
                "../350MTrain/FirstFT", low_cpu_mem_usage=True, torch_dtype=torch.float32
            ) #  
model = model.to(device) #gpu


filename = "Refinements/" + input("enter filename: ") + ".txt"

tmpD = {}


def gen_refinement_prompt(feedback):
    prompt = (
        f"\n\nFEEDBACK:\n{feedback}\n\n"
        f"OLD CODE:\n{truncate(tmpD['result_' + str(round_count - 1)], 512)}"
        f"REFINEMENT:\n{format_prompt()}"
    )
    return prompt
    
def format_prompt():
    text = tmpD['initial_prompt']
    sample_code = tmpD['result_' + str(round_count - 1)]

    # Create prompt from scratch
    prompt = f'"""\n{text}\n\n'
    prompt = f'{prompt}"""\n'
    return prompt

def truncate(ex, max_length):
    return tokenizer.decode(
        tokenizer(ex, max_length=max_length, truncation=True).input_ids
    )

round_count = 0
while True:
    if round_count == 0:
        text = input("Enter Prompt: ")
        tmpD['initial_prompt'] = text
        text = f'"""\n{text}\n"""'
        if text == "":
            break
    else:
        print("Refinement: ", round_count)
        text = input("Enter Refinement or return to finish: ")
        if text == "":
            break
        tmpD["feedback_" + str(round_count)] = text
        text = gen_refinement_prompt(text)
    print("------------------------------------------------------")
    for i in range(5):
        input_ids = tokenizer(text, truncation=True, max_length=1024, return_tensors="pt").to(device).input_ids
        generated_ids = model.generate(input_ids, num_return_sequences=1,
                        max_length=input_ids.shape[1] + 1024,
                        temperature=0.8, 
                        use_cache=True)
        output = tokenizer.decode(generated_ids[0])
        if "<|endoftext|>" in output:
            output = output[: output.find("<|endoftext|>")]
        tmpD["refinement_" + str(round_count)] = text + output
        tmpD['result_' + str(round_count)] = output
        print(output)
        print("======================================================")
    round_count += 1

with open(filename, "w") as fp:
    json.dump(tmpD, fp)  # encode dict into JSON
    fp.close()


